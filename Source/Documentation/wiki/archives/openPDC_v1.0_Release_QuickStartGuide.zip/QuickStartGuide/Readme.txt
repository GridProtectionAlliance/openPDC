openPDC Service Install Quick Start Guide
	      1/29/2010

This quick start guide assumes you have installed the openPDC into its default location:

	"C:\Program Files\TVA\openPDC\"

If not, you will need to modify the config file to reflect the correct paths as well as to modify the record in the Device table for Shelby, adjusting the file path.

Additionally, Access databases will only work in 32-bit mode. If you are using a 64-bit OS, you will need to use SQL Server, MySQL or other database that works in 64-bits. Your other option will be to run the openPDC in 32-bit mode. To use the openPDC in 64-bit mode, setup a SQL Server or MySQL database, see the online help:

http://openpdc.codeplex.com/wikipage?title=Getting%20Started&referringTitle=Documentation#set_up_database

Please follow the following steps to get started quickly:

1) After you have downloaded the release build of the openPDC (Synchrophasor.Installs.zip), make sure to unzip and install the following components:
	a) Build/Output/Release/Applications/openPDC/openPDCSetup.msi
	b) Build/Output/Release/Tools/PMUConnectionTester/PMUConnectionTesterSetup.msi

2) Once everything is installed, access Windows Services (Control Panel/Administrative Tools/Services) and find the service called openPDC. Make sure the openPDC is stopped.

3) Copy the following files (included in quick start guide) into "C:\Program Files\TVA\openPDC\", making sure to overwrite any existing files:
	a) openPDC.exe.Config
	b) openPDC.mdb
	c) openPDC.PmuConnection
	d) sample1344.PmuCapture

4) If you are using Windows Vista, Windows 7 or Windows Server 2008 or other newer version of Windows you need to navigate to "TVA/openPDC/openPDCConsole" in the start menu. Right-click on the openPDCConsole shortcut and select properties. Click on the Compatibility tab and check "Run this program as administrator" under Privilege level. Repeat this step for "TVA/PMU Connection Tester/PMU Connection Tester". * See note below for more information.

5) From the start menu run both the openPDCConsole and the PMU Connection Tester.

6) Start the openPDC Windows service from the Windows Services administrative tool.

7) You should now see the openPDCConsole connect to the service and also see operational status messages from the openPDC.

8) From the PMU Connection Tester application, navigate to "File > Connection > Load" from the menu. Open the file "C:\Program Files\TVA\openPDC\openPDC.PmuConnection". Click "Connect".

9) You should now be receiving a stream of data from the openPDC in IEEE C37.118 format.

10) Please see the online system documentation to continue your exploration of the openPDC:

	http://openpdc.codeplex.com/documentation


* Because newer versions of Windows protect the Programs Folder, you will need to use elevated privileges to run applications that modify files in this folder. The console application and PMU Connection Tester currently modify their own configuration files at runtime that are in these folders and thus require the user to run the application as administrator. You can copy these applications and their associated files to alternate locations on your computer and run the applications without this requirement.
