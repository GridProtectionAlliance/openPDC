import { OpenHistorianGrafanaDataAvailabilityChart } from './controllers/openHistorianGrafanaDataAvailabilityChart_ctrl';
export { OpenHistorianGrafanaDataAvailabilityChart as PanelCtrl };
