// Declare your constants here using format
// export const varName = {data};
// 
// Import into other code using format
// import {varName} from '../js/constants'
System.register([], function (exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var varName;
    return {
        setters: [],
        execute: function () {// Declare your constants here using format
            // export const varName = {data};
            // 
            // Import into other code using format
            // import {varName} from '../js/constants'
            exports_1("varName", varName = 'const');
        }
    };
});
//# sourceMappingURL=constants.js.map