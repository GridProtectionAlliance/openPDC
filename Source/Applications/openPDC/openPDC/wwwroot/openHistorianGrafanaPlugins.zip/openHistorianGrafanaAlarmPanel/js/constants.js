// Declare your constants here using format
// export const varName = {data};
// 
// Import into other code using format
// import {varName} from '../js/constants'
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.varName = 'const';
//# sourceMappingURL=constants.js.map