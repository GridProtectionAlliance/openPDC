export declare const varName: string;
