﻿// Declare your constants here using format
// export const varName = {data};
// 
// Import into other code using format
// import {varName} from '../js/constants'

export const varName:string = 'const'