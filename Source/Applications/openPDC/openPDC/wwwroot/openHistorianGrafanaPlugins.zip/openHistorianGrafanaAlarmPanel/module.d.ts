import { GrafanaPluginTemplateCtrl } from './controllers/grafanaPluginTemplate_ctrl';
export { GrafanaPluginTemplateCtrl as PanelCtrl };
